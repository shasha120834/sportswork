export default {
	tips: 'please selected',
	empty: 'no data',
	searchTips: 'please search',
	toolbar: {
		ALL: 'select all',
		CLEAR: 'clear',
		REVERSE: 'invert select',
		SEARCH: 'search',
	}
}