package com.sportswork.sportswork.core.mapper;

import com.sportswork.sportswork.core.entity.TestRecord;

import java.util.List;


public interface TestRecordMapper {
    void addTestRecord(TestRecord testRecord);
    TestRecord getTestRecord(String id);
    List<TestRecord> getAllTestRecords();
    void deleteTestRecord(String id);
    void setTestRecord(TestRecord testRecord);
    long getCount();
}
