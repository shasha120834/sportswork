package com.sportswork.sportswork.core.service;

import com.sportswork.sportswork.core.entity.Equipment;

import java.util.List;

/**
 * @author cpt202
 * @date 2022/3/6 15:42
 * @description
 */
public interface IEquipmentService {
    void addEquipment(Equipment equipment);
    Equipment getEquipment(String id);
    List<Equipment> getEquipmentByNameLike(String name);
    List<Equipment> getAllEquipments();
    void deleteEquipment(String id);
    void setEquipment(Equipment equipment);
    long getCount();
}
