package com.sportswork.sportswork.core.help;


public class RoleMenu {
    private String id;
    private String roleId;
    private String menuId;
}
