package com.sportswork.sportswork.core.mapper;

import com.sportswork.sportswork.core.entity.Role;

import java.util.List;


public interface RoleMapper {
    void addRole(Role role);
    Role getRole(String id);
    Role getRoleByName(String name);
    Role getRoleByDescription(String description);
    List<Role> getAllRoles();
    List<Role> getRolesByUser(String userId);
    void deleteRole(String id);
    void setRole(Role role);
    long getCount();
}
